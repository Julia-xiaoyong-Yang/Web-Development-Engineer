

## 参考链接

- [iTerm2 + Oh My Zsh 打造舒适终端体验](https://github.com/sirius1024/iterm2-with-oh-my-zsh)

- [安装oh my zsh失败：curl: (7) Failed to connect to raw.githubusercontent.com port 443: Connection refused](https://blog.csdn.net/huangpin815/article/details/105606135)

- <https://www.jianshu.com/p/246b844f4449>


