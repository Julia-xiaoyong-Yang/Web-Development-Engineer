---
title: 01-数据库的基础知识
publish: false
---

<ArticleTopAd></ArticleTopAd>



## KOA2 简介

KOA已经发展到了第二个版本，简称 KOA2。突出的特点是插件和中间件，

