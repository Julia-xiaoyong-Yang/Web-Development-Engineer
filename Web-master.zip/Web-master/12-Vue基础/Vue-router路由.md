---
title: 01-数据库的基础知识
publish: false
---

<ArticleTopAd></ArticleTopAd>





## 前言

路由：就是SPA（单页应用）的**路径管理器**。

